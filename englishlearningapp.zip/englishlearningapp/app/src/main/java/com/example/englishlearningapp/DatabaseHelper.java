package com.example.englishlearningapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "english_learning.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_QUESTIONS = "questions";
    private static final String COLUMN_ID = "id";
    private static final String COLUMN_QUESTION = "question";
    private static final String COLUMN_OPTION1 = "option1";
    private static final String COLUMN_OPTION2 = "option2";
    private static final String COLUMN_OPTION3 = "option3";
    private static final String COLUMN_CORRECT_ANSWER = "correct_answer";
    private static final String COLUMN_TOPIC = "topic";

    private static final String TABLE_WORDS = "words";
    private static final String COLUMN_WORD = "word";
    private static final String COLUMN_TRANSLATION = "translation";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_QUESTIONS_TABLE = "CREATE TABLE " + TABLE_QUESTIONS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_QUESTION + " TEXT,"
                + COLUMN_OPTION1 + " TEXT,"
                + COLUMN_OPTION2 + " TEXT,"
                + COLUMN_OPTION3 + " TEXT,"
                + COLUMN_CORRECT_ANSWER + " TEXT,"
                + COLUMN_TOPIC + " TEXT" + ")";
        db.execSQL(CREATE_QUESTIONS_TABLE);

        String CREATE_WORDS_TABLE = "CREATE TABLE " + TABLE_WORDS + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_WORD + " TEXT,"
                + COLUMN_TRANSLATION + " TEXT" + ")";
        db.execSQL(CREATE_WORDS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_QUESTIONS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_WORDS);
        onCreate(db);
    }

    public void insertQuestion(Question question) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_QUESTION, question.getQuestion());
        values.put(COLUMN_OPTION1, question.getOptions()[0]);
        values.put(COLUMN_OPTION2, question.getOptions()[1]);
        values.put(COLUMN_OPTION3, question.getOptions()[2]);
        values.put(COLUMN_CORRECT_ANSWER, question.getCorrectAnswer());
        values.put(COLUMN_TOPIC, question.getTopic());
        db.insert(TABLE_QUESTIONS, null, values);
        db.close();
    }

    public List<Question> getQuestionsByTopic(String topic) {
        List<Question> questions = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_QUESTIONS + " WHERE " + COLUMN_TOPIC + " = '" + topic + "'";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                String questionText = cursor.getString(1);
                String[] options = new String[]{cursor.getString(2), cursor.getString(3), cursor.getString(4)};
                String correctAnswer = cursor.getString(5);
                Question question = new Question(questionText, options, correctAnswer, topic);
                questions.add(question);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return questions;
    }

    public void insertWord(String word, String translation) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WORD, word);
        values.put(COLUMN_TRANSLATION, translation);
        db.insert(TABLE_WORDS, null, values);
        db.close();
    }

    public List<Word> getWords() {
        List<Word> words = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_WORDS;
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        if (cursor.moveToFirst()) {
            do {
                String word = cursor.getString(1);
                String translation = cursor.getString(2);
                Word wordObj = new Word(word, translation);
                words.add(wordObj);
            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return words;
    }

    public static class Question {
        private String question;
        private String[] options;
        private String correctAnswer;
        private String topic;

        public Question(String question, String[] options, String correctAnswer, String topic) {
            this.question = question;
            this.options = options;
            this.correctAnswer = correctAnswer;
            this.topic = topic;
        }

        public String getQuestion() {
            return question;
        }

        public String[] getOptions() {
            return options;
        }

        public String getCorrectAnswer() {
            return correctAnswer;
        }

        public String getTopic() {
            return topic;
        }
    }

    public static class Word {
        private String word;
        private String translation;

        public Word(String word, String translation) {
            this.word = word;
            this.translation = translation;
        }

        public String getWord() {
            return word;
        }

        public String getTranslation() {
            return translation;
        }
    }
}