package com.example.englishlearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;

public class FullScreenImageActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full_screen_image);

        ImageView fullScreenImageView = findViewById(R.id.fullScreenImageView);

        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("image_resource_id")) {
            int imageResourceId = intent.getIntExtra("image_resource_id", 0);
            if (imageResourceId != 0) {
                fullScreenImageView.setImageResource(imageResourceId);
            }
        }
    }
}