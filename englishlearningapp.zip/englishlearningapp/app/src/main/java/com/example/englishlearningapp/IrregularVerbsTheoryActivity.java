// IrregularVerbsTheoryActivity.java
package com.example.englishlearningapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class IrregularVerbsTheoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verbs_theory);

        RecyclerView recyclerView = findViewById(R.id.verbsRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Verb> verbs = VerbData.getVerbs();
        VerbsAdapter adapter = new VerbsAdapter(verbs);
        recyclerView.setAdapter(adapter);
    }
}