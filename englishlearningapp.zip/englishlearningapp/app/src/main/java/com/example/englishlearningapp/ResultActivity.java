package com.example.englishlearningapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        int score = getIntent().getIntExtra("score", 0);
        int totalQuestions = getIntent().getIntExtra("totalQuestions", 0);

        TextView resultTextView = findViewById(R.id.resultTextView);
        if (totalQuestions == 0) {
            resultTextView.setText("No questions answered");
        } else {
            resultTextView.setText("Your score: " + score + "/" + totalQuestions + " (" + (score * 100 / totalQuestions) + "%)");
        }

        // Сохранение прогресса
        saveProgress(score, totalQuestions);


    }

    private void saveProgress(int score, int totalQuestions) {
        SharedPreferences sharedPreferences = getSharedPreferences("MyProgress", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putInt("score", score);
        editor.putInt("totalQuestions", totalQuestions);
        editor.apply();
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(ResultActivity.this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(intent);
        finish();
    }
}