package com.example.englishlearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class TensesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_topic);

        Button theoryButton = findViewById(R.id.theoryButton);
        Button testButton = findViewById(R.id.testButton);

        theoryButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("TensesActivity", "Starting TensesTheoryActivity");
                Intent intent = new Intent(TensesActivity.this, TensesTheoryActivity.class);
                try {
                    startActivity(intent);
                } catch (Exception e) {
                    Log.e("TensesActivity", "Error starting TensesTheoryActivity", e);
                }
            }
        });

        testButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TensesActivity.this, TensesTestActivity.class);
                startActivity(intent);
            }
        });
    }
}