package com.example.englishlearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class TensesTestActivity extends AppCompatActivity {

    private static final int MAX_QUESTIONS = 8;
    private int currentQuestionIndex = 0;
    private int score = 0;
    private List<DatabaseHelper.Question> questions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test);

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        questions = dbHelper.getQuestionsByTopic("tenses");
        displayQuestion();

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAnswer();
            }
        });
    }

    private void displayQuestion() {
        TextView questionTextView = findViewById(R.id.questionTextView);
        RadioGroup optionsRadioGroup = findViewById(R.id.optionsRadioGroup);

        if (currentQuestionIndex < MAX_QUESTIONS && currentQuestionIndex < questions.size()) {
            DatabaseHelper.Question currentQuestion = questions.get(currentQuestionIndex);
            questionTextView.setText(currentQuestion.getQuestion());

            optionsRadioGroup.removeAllViews();
            for (String option : currentQuestion.getOptions()) {
                RadioButton radioButton = new RadioButton(this);
                radioButton.setText(option);
                radioButton.setTextColor(getResources().getColor(R.color.md_theme_light_textPrimary));
                radioButton.setTextSize(16);
                optionsRadioGroup.addView(radioButton);
            }
        } else {
            showResults();
        }
    }

    private void checkAnswer() {
        RadioGroup optionsRadioGroup = findViewById(R.id.optionsRadioGroup);
        int selectedId = optionsRadioGroup.getCheckedRadioButtonId();

        if (selectedId == -1) {
            return;
        }

        RadioButton selectedRadioButton = findViewById(selectedId);
        String selectedAnswer = selectedRadioButton.getText().toString();

        if (selectedAnswer.equals(questions.get(currentQuestionIndex).getCorrectAnswer())) {
            score++;
        }

        currentQuestionIndex++;

        if (currentQuestionIndex < MAX_QUESTIONS && currentQuestionIndex < questions.size()) {
            displayQuestion();
        } else {
            showResults();
        }
    }

    private void showResults() {
        Intent intent = new Intent(TensesTestActivity.this, ResultActivity.class);
        intent.putExtra("score", score);
        intent.putExtra("totalQuestions", Math.min(MAX_QUESTIONS, questions.size()));
        startActivity(intent);
        finish();
    }
}