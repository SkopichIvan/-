package com.example.englishlearningapp;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;
import java.util.List;

public class TensesTheoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private List<String> wordList;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tenses_theory);

        dbHelper = new DatabaseHelper(this);

        EditText searchWord = findViewById(R.id.search_word);
        ListView wordListView = findViewById(R.id.word_list);

        // Получаем все слова из базы данных
        wordList = new ArrayList<>();
        List<DatabaseHelper.Word> words = dbHelper.getWords();
        for (DatabaseHelper.Word word : words) {
            wordList.add(word.getWord() + " - " + word.getTranslation());
        }

        // Создаем адаптер для ListView
        adapter = new ArrayAdapter<>(this, R.layout.list_item, R.id.word_item, wordList);
        wordListView.setAdapter(adapter);

        // Добавляем слушатель для поисковой строки
        searchWord.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // Фильтруем список слов по введенному тексту
                filterWords(s.toString());
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });
    }

    private void filterWords(String query) {
        List<String> filteredList = new ArrayList<>();
        for (String word : wordList) {
            if (word.toLowerCase().contains(query.toLowerCase())) {
                filteredList.add(word);
            }
        }
        adapter.clear();
        adapter.addAll(filteredList);
        adapter.notifyDataSetChanged();
    }
}