package com.example.englishlearningapp;

public class Verb {
    private String baseForm;
    private String pastSimple;
    private String pastParticiple;
    private String translation;

    public Verb(String baseForm, String pastSimple, String pastParticiple, String translation) {
        this.baseForm = baseForm;
        this.pastSimple = pastSimple;
        this.pastParticiple = pastParticiple;
        this.translation = translation;
    }

    public String getBaseForm() {
        return baseForm;
    }

    public String getPastSimple() {
        return pastSimple;
    }

    public String getPastParticiple() {
        return pastParticiple;
    }

    public String getTranslation() {
        return translation;
    }
}