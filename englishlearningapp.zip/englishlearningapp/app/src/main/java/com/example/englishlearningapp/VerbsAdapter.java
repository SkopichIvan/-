// VerbsAdapter.java
package com.example.englishlearningapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class VerbsAdapter extends RecyclerView.Adapter<VerbsAdapter.VerbViewHolder> {

    private List<Verb> verbs;

    public VerbsAdapter(List<Verb> verbs) {
        this.verbs = verbs;
    }

    @NonNull
    @Override
    public VerbViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_verb, parent, false);
        return new VerbViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull VerbViewHolder holder, int position) {
        Verb verb = verbs.get(position);
        holder.baseFormTextView.setText(verb.getBaseForm());
        holder.pastSimpleTextView.setText(verb.getPastSimple());
        holder.pastParticipleTextView.setText(verb.getPastParticiple());
        holder.translationTextView.setText(verb.getTranslation());
    }

    @Override
    public int getItemCount() {
        return verbs.size();
    }

    static class VerbViewHolder extends RecyclerView.ViewHolder {
        TextView baseFormTextView;
        TextView pastSimpleTextView;
        TextView pastParticipleTextView;
        TextView translationTextView;

        public VerbViewHolder(@NonNull View itemView) {
            super(itemView);
            baseFormTextView = itemView.findViewById(R.id.baseFormTextView);
            pastSimpleTextView = itemView.findViewById(R.id.pastSimpleTextView);
            pastParticipleTextView = itemView.findViewById(R.id.pastParticipleTextView);
            translationTextView = itemView.findViewById(R.id.translationTextView);
        }
    }
}