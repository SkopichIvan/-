package com.example.englishlearningapp;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class VocabularyTheoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vocabulary_theory);

        TextView vocabularyTheoryTextView = findViewById(R.id.vocabularyTheoryTextView);
        String vocabularyTheoryText = "<h2>Теория времен английского языка</h2>" +
                "<p><strong>Основные времена:</strong></p>" +
                "<ul>" +
                "<li><strong>Прошедшее время (Past Tense):</strong> Для действий, которые уже произошли.</li>" +
                "<ul>" +
                "<li><strong>Past Simple (Простое прошедшее):</strong> Для законченных действий в прошлом.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> V2 (глагол во второй форме)</li>" +
                "<li><strong>Пример:</strong> I <strong>went</strong> to the park yesterday. (Я ходил в парк вчера.)</li>" +
                "</ul>" +
                "<li><strong>Past Continuous (Прошедшее длительное):</strong> Для незавершенных действий в прошлом.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> was/were + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>was reading</strong> a book when the phone rang. (Я читал книгу, когда зазвонил телефон.)</li>" +
                "</ul>" +
                "<li><strong>Past Perfect (Перфект прошедшего времени):</strong> Для действия, завершившегося до другого в прошлом.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> had + V3 (глагол в третьей форме)</li>" +
                "<li><strong>Пример:</strong> I <strong>had finished</strong> my homework before I went to bed. (Я закончил домашнее задание, прежде чем лечь спать.)</li>" +
                "</ul>" +
                "<li><strong>Past Perfect Continuous (Перфект прошедшего длительного времени):</strong> Для длительного действия до определенного момента в прошлом.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> had been + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>had been studying</strong> for two hours before I took the test. (Я учился два часа, прежде чем я написал тест.)</li>" +
                "</ul>" +
                "</ul>" +
                "<li><strong>Настоящее время (Present Tense):</strong> Для действий, происходящих сейчас или регулярно.</li>" +
                "<ul>" +
                "<li><strong>Present Simple (Простое настоящее):</strong> Для регулярных действий и общеизвестных фактов.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> V1 (глагол в первой форме)</li>" +
                "<li><strong>Пример:</strong> I <strong>go</strong> to school every day. (Я хожу в школу каждый день.)</li>" +
                "</ul>" +
                "<li><strong>Present Continuous (Настоящее длительное):</strong> Для действия, происходящего сейчас или незавершенного.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> am/is/are + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>am reading</strong> a book right now. (Я сейчас читаю книгу.)</li>" +
                "</ul>" +
                "<li><strong>Present Perfect (Перфект настоящего времени):</strong> Для действия, завершившегося к настоящему моменту.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> have/has + V3</li>" +
                "<li><strong>Пример:</strong> I <strong>have finished</strong> my homework. (Я закончил домашнее задание.)</li>" +
                "</ul>" +
                "<li><strong>Present Perfect Continuous (Перфект настоящего длительного времени):</strong> Для длительного действия до настоящего момента.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> have/has been + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>have been studying</strong> for two hours. (Я учился два часа.)</li>" +
                "</ul>" +
                "</ul>" +
                "<li><strong>Будущее время (Future Tense):</strong> Для действий, которые произойдут после момента речи.</li>" +
                "<ul>" +
                "<li><strong>Future Simple (Простое будущее):</strong> Для запланированных действий в будущем.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> will + V1</li>" +
                "<li><strong>Пример:</strong> I <strong>will go</strong> to the park tomorrow. (Я пойду в парк завтра.)</li>" +
                "</ul>" +
                "<li><strong>Future Continuous (Будущее длительное):</strong> Для действия, которое будет происходить в определенное время в будущем.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> will be + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>will be reading</strong> a book at 5 o'clock tomorrow. (Я буду читать книгу в 5 часов завтра.)</li>" +
                "</ul>" +
                "<li><strong>Future Perfect (Перфект будущего времени):</strong> Для действия, которое завершится до определенного момента в будущем.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> will have + V3</li>" +
                "<li><strong>Пример:</strong> I <strong>will have finished</strong> my homework by 6 o'clock. (Я закончу домашнее задание к 6 часам.)</li>" +
                "</ul>" +
                "<li><strong>Future Perfect Continuous (Перфект будущего длительного времени):</strong> Для длительного действия до определенного момента в будущем.</li>" +
                "<ul>" +
                "<li><strong>Форма:</strong> will have been + V-ing</li>" +
                "<li><strong>Пример:</strong> I <strong>will have been studying</strong> for two hours by 6 o'clock. (Я буду учиться два часа к 6 часам.)</li>" +
                "</ul>" +
                "</ul>" +
                "</ul>" +
                "<p><strong>Вспомогательные глаголы:</strong></p>" +
                "<p>Для образования времен используются вспомогательные глаголы:</p>" +
                "<ul>" +
                "<li><strong>Be:</strong> Для длительных времен (Continuous) и пассивного залога.</li>" +
                "<li><strong>Have:</strong> Для перфектных времен (Perfect) и пассивного залога.</li>" +
                "<li><strong>Will:</strong> Для будущего времени (Future).</li>" +
                "</ul>" +
                "<p><strong>Примеры использования времен:</strong></p>" +
                "<ul>" +
                "<li><strong>Past Simple:</strong> I <strong>went</strong> to the park yesterday. (Я ходил в парк вчера.)</li>" +
                "<li><strong>Past Continuous:</strong> I <strong>was reading</strong> a book when the phone rang. (Я читал книгу, когда зазвонил телефон.)</li>" +
                "<li><strong>Past Perfect:</strong> I <strong>had finished</strong> my homework before I went to bed. (Я закончил домашнее задание, прежде чем лечь спать.)</li>" +
                "<li><strong>Past Perfect Continuous:</strong> I <strong>had been studying</strong> for two hours before I took the test. (Я учился два часа, прежде чем я написал тест.)</li>" +
                "<li><strong>Present Simple:</strong> I <strong>go</strong> to school every day. (Я хожу в школу каждый день.)</li>" +
                "<li><strong>Present Continuous:</strong> I <strong>am reading</strong> a book right now. (Я сейчас читаю книгу.)</li>" +
                "<li><strong>Present Perfect:</strong> I <strong>have finished</strong> my homework. (Я закончил домашнее задание.)</li>" +
                "<li><strong>Present Perfect Continuous:</strong> I <strong>have been studying</strong> for two hours. (Я учился два часа.)</li>" +
                "<li><strong>Future Simple:</strong> I <strong>will go</strong> to the park tomorrow. (Я пойду в парк завтра.)</li>" +
                "<li><strong>Future Continuous:</strong> I <strong>will be reading</strong> a book at 5 o'clock tomorrow. (Я буду читать книгу в 5 часов завтра.)</li>" +
                "<li><strong>Future Perfect:</strong> I <strong>will have finished</strong> my homework by 6 o'clock. (Я закончу домашнее задание к 6 часам.)</li>" +
                "<li><strong>Future Perfect Continuous:</strong> I <strong>will have been studying</strong> for two hours by 6 o'clock. (Я буду учиться два часа к 6 часам.)</li>" ;


        vocabularyTheoryTextView.setText(Html.fromHtml(vocabularyTheoryText));
        ImageView vocabularyImageView = findViewById(R.id.vocabularyImageView);
        vocabularyImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(VocabularyTheoryActivity.this, FullScreenImageActivity.class);
                intent.putExtra("image_resource_id", R.drawable.screenshot_19);
                startActivity(intent);
            }
        });
    }
}